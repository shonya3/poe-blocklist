export { MyTabGroup } from './my-tab-group';
export { MyTabPanel } from './my-tab-panel';
export { MyTab } from './my-tab';
